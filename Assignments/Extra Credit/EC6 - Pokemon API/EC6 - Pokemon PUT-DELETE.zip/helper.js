function returnWords() {

    return "hello web dev from a helper function!";

}

exports.returnWords = returnWords